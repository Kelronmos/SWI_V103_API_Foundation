Place files:

apps/api/Cargo.toml -> <repo>/apps/api/Cargo.toml
apps/api/src/main.rs -> <repo>/apps/api/src/main.rs

Update vite.config.ts proxy target to http://localhost:3001
Run:
cargo run -p api
npm run dev
